Run main method of EvStationApplication class.
Check the port number in console, by default it is 8080